# Test component

This is a tiny fixture zip used by the e2e publish flow.
